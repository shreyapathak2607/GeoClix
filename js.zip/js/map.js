/**
 * GeoClixMap — Main Interactive Map Controller (Hackathon Edition)
 * Manages the primary Leaflet overview map, Deforestation alert markers,
 * click-to-coordinate interactions, and transitions to detailed analysis.
 *
 * @module GeoClixMap
 */
var GeoClixMap = (function () {
    'use strict';

    var map = null;
    var currentTileLayer = null;
    var alertsLayerGroup = null;
    var ndviLayerGroup = null;

    // High-priority forest loss alert locations in India with rich details
    var FOREST_ALERTS = [
        { lat: 29.5937, lng: 78.9629, name: 'Corbett Landscape Buffer', state: 'Uttarakhand', area: '3.4 km²', loss: 'Critical', driver: 'Open Mining / Encroachment', date: '2024-10-21' },
        { lat: 22.8021, lng: 80.6015, name: 'Kanha Outer Corridor', state: 'Madhya Pradesh', area: '5.1 km²', loss: 'Severe', driver: 'Linear Road Expansion', date: '2024-09-15' },
        { lat: 22.7842, lng: 82.6841, name: 'Hasdeo Arand Coal Zone', state: 'Chhattisgarh', area: '8.7 km²', loss: 'Critical (Coal Mine)', driver: 'Open-Cast Excavation', date: '2024-10-02' },
        { lat: 18.7210, lng: 81.2405, name: 'Bailadila Range Foothills', state: 'Chhattisgarh', area: '4.2 km²', loss: 'Severe', driver: 'Iron Ore Leases', date: '2024-08-28' },
        { lat: 11.9138, lng: 76.1283, name: 'Nagarhole North Periphery', state: 'Karnataka', area: '2.3 km²', loss: 'Moderate', driver: 'Commercial Timber Felling', date: '2024-07-19' },
        { lat: 26.6500, lng: 93.3500, name: 'Golaghat Tea-Forest Border', state: 'Assam', area: '6.0 km²', loss: 'Critical', driver: 'Agricultural Encroachment', date: '2024-09-30' },
        { lat: 21.6210, lng: 86.3200, name: 'Similipal Buffer Zone', state: 'Odisha', area: '3.9 km²', loss: 'Severe', driver: 'Wildfire & Illegal Logging', date: '2024-10-11' },
        { lat: 15.4200, lng: 74.2800, name: 'Bhagwan Mahaveer Fringe', state: 'Goa', area: '1.8 km²', loss: 'Moderate', driver: 'Railway Double-Tracking', date: '2024-06-14' }
    ];

    /**
     * Initializes the main map.
     */
    function init() {
        var mapContainer = document.getElementById('main-map');
        if (!mapContainer || map) return;

        // Create Leaflet map centered over India
        map = L.map('main-map', {
            center: [22.5, 82.5],
            zoom: 5,
            minZoom: 4,
            maxZoom: 18,
            zoomControl: true
        });

        // Add default satellite layer
        currentTileLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            maxZoom: 18,
            attribution: '© Copernicus Sentinel-2 / Esri World Imagery'
        }).addTo(map);

        // Alert Layer Group
        alertsLayerGroup = L.layerGroup().addTo(map);

        // NDVI Layer Group
        ndviLayerGroup = L.layerGroup().addTo(map);

        // Populate Alert Markers
        populateAlertMarkers();
        populateNdviHeatmap();

        // Setup Event Listeners
        setupMapEvents();
        setupLayerControls();

        // Initialize overview sidebar with default Corbett location
        handleLocationSelect(29.5937, 78.9629, false);

        // Fire hotspots
        if (window.GeoClixFires) {
            window.GeoClixFires.init(map);
        }

        setTimeout(function () {
            map.invalidateSize();
        }, 400);
    }

    /**
     * Populates deforestation alert markers with tactical radar blips.
     */
    function populateAlertMarkers() {
        if (!alertsLayerGroup) return;

        function renderMarkers(alerts) {
            alertsLayerGroup.clearLayers();
            alerts.forEach(function (alert) {
                var icon = L.divIcon({
                    className: 'alert-leaflet-icon',
                    html: '<div style="width:22px;height:22px;background:rgba(239,68,68,0.92);border:2px solid #ffffff;border-radius:4px;box-shadow:0 0 16px rgba(239,68,68,0.9);display:flex;align-items:center;justify-content:center;font-size:11px;color:#fff;font-weight:900;">⚠️</div>',
                    iconSize: [22, 22],
                    iconAnchor: [11, 11]
                });

                var marker = L.marker([alert.lat, alert.lng], { icon: icon });

                var popupContent = [
                    '<div style="font-family:var(--font-heading);min-width:230px;padding:4px;">',
                    '  <div style="color:#ef4444;font-weight:800;font-size:0.8rem;letter-spacing:1px;margin-bottom:4px;">⚠️ FOREST LOSS DETECTED</div>',
                    '  <div style="font-size:1.1rem;font-weight:800;color:#fff;margin-bottom:2px;">' + alert.name + '</div>',
                    '  <div style="color:#10b981;font-size:0.82rem;font-weight:600;margin-bottom:8px;">' + alert.state + '</div>',
                    '  <div style="font-size:0.82rem;color:#cbd5e1;margin-bottom:2px;">Deforested Area: <b style="color:#ef4444;">' + (alert.areaKm2 ? alert.areaKm2 + ' km²' : alert.area) + '</b></div>',
                    '  <div style="font-size:0.82rem;color:#cbd5e1;margin-bottom:2px;">Primary Driver: <b>' + alert.driver + '</b></div>',
                    '  <div style="font-size:0.82rem;color:#94a3b8;margin-bottom:12px;">Alert Revisit: ' + (alert.detectionDate || alert.date) + '</div>',
                    '  <button onclick="window.GeoClixApp.openAnalysis(' + alert.lat + ',' + alert.lng + ')" ',
                    '    style="width:100%;padding:8px;background:#10b981;color:#041407;font-weight:800;border:none;border-radius:4px;cursor:pointer;text-transform:uppercase;letter-spacing:0.5px;">',
                    '    Launch "Then vs Now" Split Analysis ➔',
                    '  </button>',
                    '</div>'
                ].join('');

                marker.bindPopup(popupContent);
                alertsLayerGroup.addLayer(marker);
            });
        }

        // Try to fetch alerts live from backend API first
        if (window.GeoClixAPI) {
            GeoClixAPI.getAlerts()
                .then(function (liveAlerts) {
                    if (liveAlerts && liveAlerts.length > 0) {
                        renderMarkers(liveAlerts);
                    } else {
                        renderMarkers(FOREST_ALERTS);
                    }
                })
                .catch(function () {
                    renderMarkers(FOREST_ALERTS);
                });
        } else {
            renderMarkers(FOREST_ALERTS);
        }
    }

    /**
     * Adds an NDVI canopy health heatmap layer across forested zones.
     */
    function populateNdviHeatmap() {
        if (!ndviLayerGroup) return;

        // Western Ghats NDVI polygon
        var wg = L.polygon([
            [15.5, 73.8], [14.0, 74.5], [11.5, 75.8], [10.0, 76.5], [12.0, 75.2], [14.5, 74.0]
        ], {
            color: '#4ade80',
            weight: 1.5,
            fillColor: '#22c55e',
            fillOpacity: 0.25
        }).bindPopup('<b>Western Ghats Biosphere:</b> High Canopy NDVI (0.84)');

        // Central India Sal Forest NDVI polygon
        var ci = L.polygon([
            [23.5, 80.0], [21.5, 80.5], [21.0, 83.0], [23.0, 83.5]
        ], {
            color: '#4ade80',
            weight: 1.5,
            fillColor: '#22c55e',
            fillOpacity: 0.25
        }).bindPopup('<b>Central India Corridor:</b> Moderate Canopy NDVI (0.72)');

        ndviLayerGroup.addLayer(wg);
        ndviLayerGroup.addLayer(ci);
    }

    /**
     * Map events: mousemove (live coords) and click.
     */
    function setupMapEvents() {
        if (!map) return;

        var infoText = document.getElementById('map-info-text');

        map.on('mousemove', function (e) {
            if (infoText && window.GeoClixCoordinates) {
                var latStr = GeoClixCoordinates.formatCoord(e.latlng.lat, 'lat');
                var lngStr = GeoClixCoordinates.formatCoord(e.latlng.lng, 'lng');
                infoText.textContent = latStr + '  •  ' + lngStr + '  (Click anywhere or select red alert to analyze)';
            }
        });

        map.on('click', function (e) {
            handleLocationSelect(e.latlng.lat, e.latlng.lng, true);
        });
    }

    /**
     * Handles selection of a location.
     * @param {number} lat
     * @param {number} lng
     * @param {boolean} promptAnalysis
     */
    function handleLocationSelect(lat, lng, promptAnalysis) {
        if (window.GeoClixCoordinates) {
            GeoClixCoordinates.updateCoordinateDisplays(lat, lng);
        }

        // Update Forest Intelligence Sidebar Metrics
        var canopyEl = document.getElementById('ov-canopy');
        var lossEl = document.getElementById('ov-loss');
        var carbonEl = document.getElementById('ov-carbon');
        var driverEl = document.getElementById('ov-driver');
        var elevEl = document.getElementById('ov-elevation');

        // Deterministic realistic values based on coordinates
        var seed = Math.abs(Math.sin(lat * 12.9898 + lng * 78.233) * 43758.5453);
        var canopyPct = (55 + (seed % 35)).toFixed(1);
        var lossKm = (1.5 + (seed % 6)).toFixed(1);
        var carbonTon = Math.round(8000 + (seed % 22000));
        var drivers = ['MINING', 'ROAD CUT', 'AGRICULTURE', 'LOGGING', 'WILDFIRE'];
        var driver = drivers[Math.floor(seed) % drivers.length];
        var elev = Math.round(250 + (seed % 750));

        if (canopyEl) canopyEl.textContent = canopyPct + '%';
        if (lossEl) lossEl.textContent = '-' + lossKm + ' km²';
        if (carbonEl) carbonEl.textContent = carbonTon.toLocaleString() + ' t';
        if (driverEl) driverEl.textContent = driver;
        if (elevEl) elevEl.textContent = elev + ' m';

        // Connect to Backend API for live telemetry
        if (window.GeoClixAPI) {
            GeoClixAPI.getWeather(lat, lng)
                .then(function (weather) {
                    var statusEl = document.getElementById('ov-landtrendr-val');
                    if (statusEl && weather.sensorOptimal) {
                        statusEl.textContent = weather.sensorOptimal;
                    }
                })
                .catch(function () {});
        }

        if (promptAnalysis && window.GeoClixApp) {
            window.GeoClixApp.showToast(
                'Launching Satellite Analysis for ' + lat.toFixed(4) + '° N, ' + lng.toFixed(4) + '° E...',
                '🛰️',
                2500
            );

            setTimeout(function () {
                window.GeoClixApp.openAnalysis(lat, lng);
            }, 300);
        }
    }

    /**
     * Sets up map controls: layer buttons & overlay checkboxes.
     */
    function setupLayerControls() {
        var layerBtns = document.querySelectorAll('.layer-btn');
        layerBtns.forEach(function (btn) {
            btn.addEventListener('click', function () {
                layerBtns.forEach(function (b) { b.classList.remove('active'); });
                btn.classList.add('active');

                var layerType = btn.getAttribute('data-layer');
                if (window.GeoClixSatellite) {
                    currentTileLayer = GeoClixSatellite.switchLayer(map, currentTileLayer, layerType);
                }
            });
        });

        // Overlay Toggles
        var toggleFires = document.getElementById('toggle-fires');
        if (toggleFires) {
            toggleFires.addEventListener('change', function () {
                if (window.GeoClixFires) {
                    GeoClixFires.toggleFires(map, toggleFires.checked);
                }
            });
        }

        var toggleAlerts = document.getElementById('toggle-alerts');
        if (toggleAlerts) {
            toggleAlerts.addEventListener('change', function () {
                if (toggleAlerts.checked) {
                    map.addLayer(alertsLayerGroup);
                } else {
                    map.removeLayer(alertsLayerGroup);
                }
            });
        }

        var toggleNdvi = document.getElementById('toggle-ndvi');
        if (toggleNdvi) {
            toggleNdvi.addEventListener('change', function () {
                if (toggleNdvi.checked) {
                    map.addLayer(ndviLayerGroup);
                } else {
                    map.removeLayer(ndviLayerGroup);
                }
            });
        }
    }

    return {
        init: init,
        getMap: function () { return map; },
        invalidateSize: function () { if (map) map.invalidateSize(); },
        handleLocationSelect: handleLocationSelect
    };
})();

window.GeoClixMap = GeoClixMap;
